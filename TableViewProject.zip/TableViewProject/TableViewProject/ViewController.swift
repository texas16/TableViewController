//
//  ViewController.swift
//  TableViewProject
//
//  Created by ilyas uyanik on 1/26/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

