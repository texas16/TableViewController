//
//  CustomTableViewController.swift
//  TableViewProject
//
//  Created by ilyas uyanik on 1/26/25.
//

import Foundation
import UIKit

// CollectionViewController
class CustomTableViewController : UITableViewController {
    
    let fruitItems = ["Apple", "Banana", "Cherry", "Date", "Fig", "Grape"]
    let countryItems = ["Germany", "Turkey", "Russia", "US", "Japan"]

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Second Class Exercise"
        //tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }
    
    // MARK: - Table view data source

    // number of sections in the table
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2 // section
    }
    
    // number of rows in section
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return fruitItems.count
        } else {
            return countryItems.count
        }
    }
    
    // Configure each cell
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        if indexPath.section == 0 {
            cell.textLabel?.text = fruitItems[indexPath.row]
            cell.accessoryType = .detailButton
        } else if indexPath.section == 1 {
            cell.textLabel?.text = countryItems[indexPath.row]
            cell.accessoryType = .checkmark
        }
        return cell
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0 {
            return "Fruits"
        } else {
            return "Countries"
        }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        var selectedItem: String = ""
        if indexPath.section == 0 {
            selectedItem = fruitItems[indexPath.row]
        } else if indexPath.section == 1 {
            selectedItem = countryItems[indexPath.row]
        }
        
        let alert = UIAlertController(title: "You selected", message: selectedItem, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
        
    }
}

// CollectionViewController
// Navigation (from CollectionView -> Custom View)
// High order functions (map, flat, sum, etc..)
